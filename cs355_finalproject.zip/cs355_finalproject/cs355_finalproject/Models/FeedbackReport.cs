﻿using System.ComponentModel.DataAnnotations;
namespace cs355_finalproject.Models
{
    public class FeedbackReport
    {
        [Required(ErrorMessage = "A FeedbackReport ID was not created!")]
        public int Id { get; set; }
        
        [Required(ErrorMessage = "Please select a game to feedback.")]
        public string GameSelected { get; set; }
        public int Rating { get; set; }
        [Required(ErrorMessage = "Please leave a response.")]
        public string FirstResponse { get; set; }
        [Required(ErrorMessage = "Please leave a response.")]
        public string LastResponse { get; set; }
    }
}

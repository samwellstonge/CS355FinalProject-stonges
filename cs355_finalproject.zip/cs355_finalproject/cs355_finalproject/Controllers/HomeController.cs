﻿using cs355_finalproject.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace cs355_finalproject.Controllers
{
    public class HomeController : Controller
    {
        private readonly Data.ApplicationDbContext _db;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger) {
            _logger = logger;
            _db = new Data.ApplicationDbContext();
        }

        public IActionResult Index() {
            return View();
        }

        public IActionResult About() {
            return View();
        }

        public IActionResult Feedback() {
            return View();
        }

        [HttpPost]
        public IActionResult FeedbackValidate(FeedbackReport report) {
            //I am very aware I should not be using a random here.
            var ran = new Random();
            report.Id = ran.Next(1, 100000000);
            if(ModelState.IsValid) {
                List<FeedbackReport>? reports = _db.FeedbackReports.ToList();
                reports.Add(report);
                return RedirectToAction("Success");
            } else {
                return View(report);
            }
        }



        public IActionResult Success() {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error() {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
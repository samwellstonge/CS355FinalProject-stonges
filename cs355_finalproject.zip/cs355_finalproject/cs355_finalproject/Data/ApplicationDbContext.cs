﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using cs355_finalproject.Models;

namespace cs355_finalproject.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public DbSet<FeedbackReport>? FeedbackReports { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {
            optionsBuilder.UseSqlServer(connectionString: "tempstring");
            //- !
        }
    }
}
